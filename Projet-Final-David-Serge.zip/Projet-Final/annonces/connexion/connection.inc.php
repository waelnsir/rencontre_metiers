<?php
   
/* Ce fichier construit la connexion à la base de données  */
class Connexion{
	private $serveur;
	private $usager;
	private $motPasse;
	private $baseDonnees;
	private $connexion;
	public  $CONNECTION_ID;
	
	function __construct($serveur, $usager, $motPasse, $baseDonnees,$CONNECTION_ID=null){
		$this->serveur=$serveur;
		$this->usager=$usager;
		$this->motPasse=$motPasse;
		$this->baseDonnees=$baseDonnees;
	}
	
	function getConnexion(){
		return $this->connexion;
	}
	
	function connecter(){
	   try {
		  $dns = "mysql:host=$this->serveur;dbname=$this->baseDonnees";
		  $options = array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION  );
		  $this->connexion = new PDO( $dns, $this->usager, $this->motPasse, $options );
	} catch ( Exception $e ) {
			echo $e->getMessage();
			echo "<br>Probleme de connexion au serveur de bd!";
			exit(-1);
		}
		
	}
	
	
}

    