
/** Ce fichier gère toutes les requetes d'enregistrement de données venant du controller et retourne des données à afficher vers la vue */
var tabFilms=[];
//listeFilms 
function requeteLire(){
	var formAssur = new FormData();
	formAssur.append('action','listeFilms');
	
	$.ajax({
		type : 'POST',
		url : './server/controller/gestionFilms.php',
		data : formAssur,
		dataType : 'json', //text pour le voir en format de string
		//async : false, //la requete doit être synchrone ici
		cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){
            tabFilms = reponse.listeFilms;
           
            nouveautes(tabFilms);
		},
		fail : function (err){
		   alert("Problème pour lister!" + err);
		}
	});
}


//listeFilms
function listeFilms(){

    var affiche = document.getElementById('affichage');
    
	res="";
	for(elem of tabFilms){
    
          if(elem){
             //si l'élément existe on construit la card à afficher ainsi que le preview
              res+=uneCard(elem);
              res+=previews(elem);
          }
            
        }
	if(affiche){
      document.getElementById("titre").innerHTML = "Liste de tous les films";
	    affiche.innerHTML = res;
    }
}



  //liste des films charger par defaut
  function nouveautes(tab){
    var affiche = document.getElementById('affichage');
    
	  res="";i=0;
    //for(index = tab.length; index > 0 ; index--);
    index = 4;
    while(index >= 0 ){
        if(elem = tab[index]){
          //si l'élément existe on construit la card à afficher ainsi que le preview
            res+= uneCard(elem);
            res+= previews(elem);
        }
        index--;   
    };

    if(affiche)
    affiche.innerHTML = res;
  }


  //lecture par catégorie
  function categories(catego){

    var affiche = document.getElementById('affichage');
    
	res="";
	for(elem of tabFilms){

            if(elem && elem.categ == catego){
                
                res+=uneCard(elem);
                res+=previews(elem);
            }
            
        }
	if(affiche){
        document.getElementById("titre").innerHTML = "Liste des films de la catégorie " + catego;
	    affiche.innerHTML = res;
    } 
    if( catego == ""){

        document.getElementById("affichage").innerHTML = "<div class=\"alert alert-warning\" role=\"alert\">Aucun choix effectué! <br>Veuillez choisir une catégorie svp.</div>";
   
    }
   
  }


//construction d'une card
function uneCard(row){
    
    card= "<div class='card bg-light mb-3' >";
    card += "<div class=\"nav-item\" ><a href=\"row.preview\" class=\"nav-link\" data-toggle=\"modal\" data-target=#modal"+row.idfilms+">";              
    card += "<img src='./src/images/pochettes/"+row.urlimg +"' class='card-img' alt='"+row.titre +"' /></a></div>";
    card+= "<div class='card-header'><h5>"+row.titre +"</h5></div>";
    card+= "<div class='card-body'>";
    card+= "<p class='card-text'>"+row.rea +"</p>";
    card+= "<p class='card-text'><b>"+row.categ +"</b></p>";
    card+= "<p class='card-text'>$"+row.prix +"</p>";
    card+= "<p class='card-text'>"+row.duree+"min</p>";
    card+= "</div>";
    card+= "</div>";
    return card;
  }


//construction du preview
function previews(row){
    
    resu="";
    resu+="	<div onclose=$('idVideo" + row.idfilms +"').pause() class=\"modal modalVideo fade\" id=\"modal"+row.idfilms+"\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"previewLabel\" aria-hidden=\"true\">\n";
    resu+="	  <div class=\"modal-dialog\" role=\"document\">\n";
    resu+="		<div class=\"modal-content\">\n";
    resu+="		  <div class=\"modal-header\">\n";
    resu+="			<h5 class=\"modal-title\" id=\"previewLabel\">"+row.titre+"</h5>\n";
    resu+="			<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\" title=\"Close\" onclick=\"videoStop('idVideo"+row.idfilms+"')\" >\n";
    resu+="			  <span aria-hidden=\"true\">×</span>\n";
    resu+="			</button>\n";
    resu+="			\n";
    resu+="		</div>\n";
    resu+="		<div class=\"modal-body\">\n";
    resu+="            <video width=\"100%\" height=\"100%\"  id=\"idVideo" + row.idfilms +"\" class='video'  onclick=gererVideo(this) controls>\n";
    resu+="              <source src=\"./src/images/previews/"+row.preview+"\" type='video/mp4'>\n";
    //resu+="  <source src=\"+/src/images/previews\row+preview\" type=\"video/ogg\">\n";
    resu+="            </video>";
    resu+="		</div>\n";
    resu+="		<div class=\"modal-footer\"></div>\n";
    resu+="		</div>\n";
    resu+="	  </div>\n";
    resu+="	</div>";
    
     return resu;
}

//fonction pour controler le temps de chargement de la page
function timeLoading(tab){
  
  if(tab.length == 0){
      $("#affichage").html("<span style='height:100px;' class='alert alert-warning'>La page met trop de temps pour charger!<br>Veuillez re-essayer plus tard.</span>");
    }
}
setTimeout(function(){
  
    timeLoading(tabFilms); 
    
  },15000);