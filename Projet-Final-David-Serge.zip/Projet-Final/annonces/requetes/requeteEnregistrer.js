///
attente = "<div class='container bg-light' style='width:320px; font-size:20px;color:green;text-align:center'> <br>";
attente+="<div class='spinner-grow text-primary container' id='loading2' role='status'>"  ;     
attente+="<span class='sr-only'>Loading...</span>";
attente+="</div></div>";



//enregistrer film 
function requeteEnreg(formId,btn){
	var formFilm = new FormData(document.getElementById(formId));
	formFilm.append('action',formId);
	$("#msg").html(attente);
	
		//console.log("retour = " + valider(formId));
	if(val = valider(formId)){
		btn.disabled = true;
		console.log("retour = " + val);
		$.ajax({
			type : 'POST',
			url : './server/controller/gestionFilms.php',
			data : formFilm,
			dataType : 'json', //text pour le voir en format de string
			async : true,
			cache : false,
			contentType : false,
			processData : false,
			success : function (reponse){
				//alert(reponse);
				var msg="";
				if(reponse.ok ){
					msg = reponse.ok;
					btn.disabled = false;
					$("#enregistrerFilms input[type=text]").each(function(index,valeur){
						valeur.value="";
					});
					$("#msg").css("color","green");
				}else{
					msg = reponse.error;
					msg += "<br>"+reponse.msg_video;
					msg += "<br>"+reponse.msg_image;
					$("#msg").css("color","red");
					btn.disabled=false;
					alert(msg);
				}
				$("#msg").html(msg);
				setTimeout(function(){
					$("#msg").html("");
					btn.disabled=false;
				},5000);
				
				
			},
			fail : function (err){
				$("#msg").html(err);
			}
		});
	}
}

