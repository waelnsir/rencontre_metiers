<?php session_start() ?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
	
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Layal</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="../css/linearicons.css">
		<link rel="stylesheet" href="../css/owl.carousel.css">
		<link rel="stylesheet" href="../css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/nice-select.css">
		<link rel="stylesheet" href="../css/magnific-popup.css">
		<link rel="stylesheet" href="../css/bootstrap.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous">
		
			

	</head>
	<body>
		<div class="main-wrapper-first">
			<div class="hero-area relative">

				
				<header>
					<div class="container">
						
						
						<div class="header-wrap">
							<div class="header-top d-flex justify-content-between align-items-center">
								
								<div class="logo">
									<a href="../index.html"><img src="../img/logo.png" alt=""></a>
								</div>
							
								<div class="main-menubar d-flex align-items-center">
									<nav class="hide">
										<a href="../index.html">Home</a>
										<a href="../generic.html">Matériaux ou produits</a>
										<a href="./">Services ou emplois</a>
										<a href="../forum.html">Forums</a>
									</nav>

									<nav class="login">
										<a href="../s'inscrire.html">Créer un compte</a>
										<a href="../index.html#openModal14">Se connecter</a>
										
									</nav>
									<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
								</div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</div>
		<div class="main-wrapper">
			<!-- Start banner Area -->
			<div class="banner-area">
				<div class="container">
					<div class="section-top-border">
						<h2 class="mb-30 fr">Liste des annonces </h2>
						    <!-- Button trigger modal -->
						<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalannonce">
							Ajouter une annonce
						</button><br><br><div></div>
            <?php
              include("read.php");
            ?>
						<div class="row">
                                             

          <!--  
              <div class="col-md-4 ">
								<div class="single-defination">
                                        <img src="img/peintre.jpg" alt="" class="img-fluid">
									<h4 class="mb-20">Peintre</h4>
									<p class="par">Partagez vos expériences avec vos collègues <span class="lnr lnr-arrow-right"></span></p>
								</div>
              </div> 
              -->
						</div>
          </div>
				</div>
			</div>
			<!-- End banner Area -->
			

      
  <!-- Modal -->
  <div class="modal fade" id="modalannonce" tabindex="-1" role="dialog" aria-labelledby="modalannonceTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalannonceTitle">Ajout d'une annonce</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!-- formulaire d'enregistrement de l'annonce -->
            <form method="post" id="create"  enctype="multipart/form-data" onsubmit="return create('create',this)" >
                    <input type="hidden" name="idmembres" value=<?php echo $_SESSION['idmembres']; ?> >
                    <div class="form-group">
                      <label for="titre">Titre</label>
                      <input type="text" class="form-control validate" id="titre" name="titre" required placeholder="Titre de l'annonce" autofocus="true" > 
                      
                    </div>
                    <div class="form-group">
                      <label for="type_annonces">De quel type d'annonce s'agit-il?</label>
                      <select class="form-control" id="type_annonces" name="type_annonces"> 
                          <!--<option value="choisir">choisir</option> -->
                          <option value="emploi">emplois</option>
                          <option value="benevolat">bénevolat</option>
                          <option value="produit">produit</option>
                          <option value="materiel">materiel</option>
                          <option value="stage">stage</option>
                      </select>
                    </div>
                    <div class="form-group ">
                      <label class="form-label" for="type_action">Que voulez-vous faire?</label>
                      <select class="form-control"  name="type_action" id="type_action">
                        <!--<option value="choisir">choisir</option> -->
                        <option value="donner">donner</option>
                        <option value="louer">louer</option>
                        <option value="vendre">vendre</option>
                      </select>
                    </div>
                    <div class="form-group">
                        <label for="lieu">Adresse du lieu</label>
                        <input class="form-control" type="address" class="form-control validate" id="lieu" name="lieu" placeholder="Entrer l'adresse du lieu" required>
                    </div>
                    <div class="form-group">
                        <label for="lieu">Contenu de votre message:</label>
                        <textarea class="form-control validate" name="message" id="message" cols="30" rows="10" placeholder="Votre annonce ici" required></textarea>
					</div>
					<div id="msg"></div>
                    <div class="form-group">
                      <label for="fichier">Déposez vos fichiers ici:</label><br>
                      <input type="file" name="fichier[]" multiple="true" id="fichier1">
                      <input type="file" name="fichier[]" multiple="true" id="fichier2">
                      <input type="file" name="fichier[]" multiple="true" id="fichier3">
                      <div>Seuls les fichiers de types: <i> photos(.jpeg, .jpg, .png), videos(.mp4) et documents(.doc,.pdf)</i> .</div>
                    </div>

        </div>
        <div class="modal-footer">
          <button type="reset" class="btn btn-danger">Reset</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Envoyer</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  <!-- fin du modal pour create annonce -->


			<!-- Start Footer Section -->
			<footer class="footer-area pt-100 pb-20">
				<div class="container">
					<div class="row">
						
						
					</div>
					<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						<p class="footer-text m-0">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
					</div>
				</div>
			</footer>
			<!-- End Footer Section -->
		</div>
		<script src="../js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="../js/vendor/bootstrap.min.js"></script>
		<script src="../js/jquery.ajaxchimp.min.js"></script>
		<script src="../js/owl.carousel.min.js"></script>
		<script src="../js/jquery.nice-select.min.js"></script>
		<script src="../js/jquery.magnific-popup.min.js"></script>
        <script src="../js/main.js"></script>
        <script src="./requetes/create.js"></script>
        <script src="./requetes/script.js"></script>
        <script src="./requetes/update.js"></script>
        
	</body>
</html>
