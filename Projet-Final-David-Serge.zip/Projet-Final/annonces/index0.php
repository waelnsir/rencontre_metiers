<?php
  session_start();
  $_SESSION["prenom"] = "salomon";//des variables qui seront obtenues via le login
  $_SESSION["idmembres"] = "4";//des variables qui seront obtenues via le login
  include("header.php");
?>

<body>
   <br> <br><div>Bienvenue sur la page des annonces</div> <br><hr><br>

    <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalannonce">
    Ajouter une annonce
  </button>

<div class="container">
  <?php
    include("./read.php");
  ?>
</div>
  <!-- Modal -->
  <div class="modal fade" id="modalannonce" tabindex="-1" role="dialog" aria-labelledby="modalannonceTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalannonceTitle">Ajout d'une annonce</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!-- formulaire d'enregistrement de l'annonce -->
            <form action="./create.php" method="post" id="create"  enctype="multipart/form-data" onsubmit="return true">
                    <input type="hidden" name="idmembres" value=<?php echo $_SESSION['idmembres']; ?> >
                    <div class="form-group">
                      <label for="titre">Titre</label>
                      <input type="text" class="form-control validate" id="titre" name="titre" required placeholder="Titre de l'annonce" autofocus="true" > 
                      
                    </div>
                    <div class="form-group">
                      <label for="type_annonces">De quel type d'annonce s'agit-il?</label>
                      <select class="form-control" id="type_annonces" name="type_annonces"> 
                          <option value="choisir">choisir</option>
                          <option value="emploi">emplois</option>
                          <option value="benevolat">bénevolat</option>
                          <option value="produit">produit</option>
                          <option value="materiel">materiel</option>
                          <option value="stage">stage</option>
                      </select>
                    </div>
                    <div class="form-group ">
                      <label class="form-label" for="type_action">Que voulez-vous faire?</label>
                      <select class="form-control"  name="type_action" id="type_action">
                        <option value="choisir">choisir</option>
                        <option value="donner">donner</option>
                        <option value="louer">louer</option>
                        <option value="vendre">vendre</option>
                      </select>
                    </div>
                    <div class="form-group">
                        <label for="lieu">Adresse du lieu</label>
                        <input class="form-control" type="address" class="form-control validate" id="lieu" name="lieu" placeholder="Entrer l'adresse du lieu" required>
                    </div>
                    <div class="form-group">
                        <label for="lieu">Contenu de votre message:</label>
                        <textarea class="form-control validate" name="message" id="message" cols="30" rows="10" placeholder="Votre annonce ici"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="fichier">Déposez vos fichiers ici:</label><br>
                      <input type="file" name="fichier[]" multiple="true" id="fichier1">
                      <input type="file" name="fichier[]" multiple="true" id="fichier2">
                      <input type="file" name="fichier[]" multiple="true" id="fichier3">
                      <div>Seuls les fichiers de types: <i> photos(.jpeg, .jpg, .png), videos(.mp4) et documents(.doc,.pdf)</i> .</div>
                    </div>

                     
                    <button type="reset" class="btn btn-danger">Reset</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="reset" class="btn btn-primary" onclick="create('create',this)">Save changes</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  <!-- fin du modal pour create annonce -->


<script src="./requetes/create.js"></script>
<script src="./requetes/script.js"></script>
</body>
</html>