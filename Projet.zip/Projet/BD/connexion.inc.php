<?php


	define("SERVEUR","localhost");
	define("USAGER","root");
	define("PASSE","");
	define("BD","rencontres");
	$connexion = new mysqli(SERVEUR,USAGER,PASSE,BD);
	if ($connexion->connect_errno) {
		echo "Probleme de connexion au serveur de bd";
		exit();
	}


	$con = mysqli_connect("localhost","root","","dbrencontres_test");
		if (mysqli_connect_errno()){
	 echo "Failed to connect to MySQL: " . mysqli_connect_error();
	 die();
	 }
	 
	date_default_timezone_set('Asia/Karachi');
	$error="";

	
 /* 	// Connection variables
	 $dbhost	= "localhost";	   // localhost or IP
	$dbuser	= "root";		  // database username
	$dbpass	= "";		     // database password
	$dbname	= "dqbdfilms";    // database name  */
	
 
	
?>