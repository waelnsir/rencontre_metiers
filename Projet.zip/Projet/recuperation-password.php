


<?php
include('BD/connexion.inc.php');
if(isset($_POST["email"]) && (!empty($_POST["email"]))){
$email = $_POST["email"];
$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$email = filter_var($email, FILTER_VALIDATE_EMAIL);
if (!$email) {
   $error .="<p>Invalid email address please type a valid email address!</p>";
   }else{
   $sel_query = "SELECT * FROM `membres` WHERE email='".$email."'";
   $results = mysqli_query($con,$sel_query);
   $row = mysqli_num_rows($results);
   if ($row==""){
   $error .= "<p>No user is registered with this email address!</p>";
   }
  }
   if($error!=""){
   echo "<div class='error'>".$error."</div>
   <br /><a href='javascript:history.go(-1)'>Go Back</a>";
   }else{
   $expFormat = mktime(
   date("H"), date("i"), date("s"), date("m") ,date("d")+1, date("Y")
   );
   $expDate = date("Y-m-d H:i:s",$expFormat);
   $key = md5($email);
   $addKey = substr(md5(uniqid(rand(),1)),3,10);
   $key = $key . $addKey;
// Insert Temp Table
mysqli_query($con,
"INSERT INTO `password_reset_temp` (`email`, `key`, `expDate`)
VALUES ('".$email."', '".$key."', '".$expDate."');");
 $output=' <link href="http://localhost:8080/projet/index.html" media="screen" type="text/css" />';
$output='<p>Cher utilisateur,</p>';
$output.='<p>Veuillez cliquer sur le lien suivant pour réinitialiser votre mot de passe.</p>';
$output.='<p>-------------------------------------------------------------</p>';
$output.='<p><a href="http://localhost:8080/projet/reset-password.php?
key='.$key.'&email='.$email.'&action=reset" target="_blank">
http://localhost:8080/projet/reset-password.php
?key='.$key.'&email='.$email.'&action=reset</a></p>'; 
$output.='<p>-------------------------------------------------------------</p>';
$output.='<p>Assurez-vous de copier l\'intégralité du lien dans votre navigateur. Le lien expirera après 1 jour pour des raisons de sécurité.</p>';
$output.='<p>Si vous n\'avez pas demandé cet e-mail de mot de passe oublié, aucune action n\'est nécessaire, votre mot de passe ne sera pas réinitialisé. Cependant,
 vous voudrez peut-être vous connecter à votre compte et modifier votre mot de passe de sécurité </p>';   
$output.='<p>Merci,</p>';
$output.='<p>Équipe Layal</p>';
$body = $output; 
$subject = "Récupération de mot de passe - Layal.ca";

$email_to = $email;
$fromserver = "noreply@yourwebsite.com"; 
require("C:/xampp/htdocs/composer/PHPMailer-5.2-stable/PHPMailerAutoload.php");
$mail = new PHPMailer();
$mail->CharSet = "UTF-8";
$mail->IsSMTP();
$mail->Host = "localhost"; // Enter your host here
$mail->SMTPAuth = true;
$mail->Username = "waelnsir@gmail.com"; // Enter your email here
$mail->Password = "love4amani"; //Enter your password here
$mail->Port = 25;
$mail->IsHTML(true);
$mail->From = "noreply@layal.ca";
$mail->Host = 'tls://smtp.gmail.com:587'; 
$mail->FromName = "LAYAL";
$mail->Sender = $fromserver; // indicates ReturnPath header
$mail->Subject = $subject;
$mail->Body = $body;
$mail->AddAddress($email_to);
if(!$mail->Send()){
echo "Mailer Error: " . $mail->ErrorInfo;
}else{
echo '
<script>alert("Un courriel a été envoyé a '.$email.' avec des instructions sur la réinitialisation de votre mot de passe.")</script>';

 
//Set Refresh header using PHP.
header( "refresh:0;url=http://localhost:8080/projet/login.html" );
 
}
   }
}else{
?>
<form method="post" action="" name="reset"><br /><br />
<label><strong>Enter Your Email Address:</strong></label><br /><br />
<input type="email" name="email" placeholder="username@email.com" />
<br /><br />
<input type="submit" value="Reset Password"/>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php } ?>