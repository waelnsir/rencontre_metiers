<?php


	define("SERVEUR","localhost");
	define("USAGER","root");
	define("PASSE","");
	define("BD","rencontres");
	$connexion = new mysqli(SERVEUR,USAGER,PASSE,BD);
	if ($connexion->connect_errno) {
		echo "Probleme de connexion au serveur de bd";
		exit();
	}



	
 /* 	// Connection variables
	 $dbhost	= "localhost";	   // localhost or IP
	$dbuser	= "root";		  // database username
	$dbpass	= "";		     // database password
	$dbname	= "dqbdfilms";    // database name  */
	
 
	
?>